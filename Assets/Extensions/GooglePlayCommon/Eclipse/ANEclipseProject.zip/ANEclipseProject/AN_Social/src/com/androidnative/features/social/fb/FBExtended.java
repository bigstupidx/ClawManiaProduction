package com.androidnative.features.social.fb;

import android.os.Bundle;
import android.util.Log;
import com.androidnative.features.social.utils.SocialConf;
import com.facebook.Session;
import com.facebook.widget.WebDialog;




public class FBExtended {

	
	public static void SendRequest(String title, String messgae, String data, String to) {
		Log.d("AndroidNative", " SendRequest with data");
		 Bundle params = new Bundle();
		 	params.putString("title", title);
		    params.putString("message", messgae);
		    params.putString("action_type", "turn");
		    params.putString("data", data);
		    params.putString("to", to);


		    WebDialog requestsDialog = (
		        new WebDialog.RequestsDialogBuilder(SocialConf.GetLauncherActivity(),
		            Session.getActiveSession(),
		            params))
		            .setOnCompleteListener(new FBAppRequestCompleteListner())
		            .build();
		    
		    
		    requestsDialog.show();
		 
	}
}
