/*
ы * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.androidnative.gcm;



import java.util.List;

import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;

/**
 * This {@code IntentService} does the actual handling of the GCM message.
 * {@code GcmBroadcastReceiver} (a {@code WakefulBroadcastReceiver}) holds a
 * partial wake lock for this service while the service does its work. When the
 * service is finished, it calls {@code completeWakefulIntent()} to release the
 * wake lock.
 */
public class GcmIntentService extends IntentService {
    public static final int NOTIFICATION_ID = 1;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;

    public GcmIntentService() {
        super("GcmIntentService");
    }
    public static final String TAG = "AndroidNative";

    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
        // The getMessageType() intent parameter must be the intent you received
        // in your BroadcastReceiver.the
        String messageType = gcm.getMessageType(intent);

        if (!extras.isEmpty()) {  // has effect of unparcelling Bundle
            /*
             * Filter messages based on message type. Since it is likely that GCM will be
             * extended in the future with new message types, just ignore any message types you're
             * not interested in, or that you don't recognize.
             */
            if (GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
             //   sendNotification("Send error: " + extras.toString());
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_DELETED.equals(messageType)) {
             //   sendNotification("Deleted messages on server: " + extras.toString());
            // If it's a regular GCM message, do some work.
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType)) {
                // This loop represents the service doing some work.
               
                // Post notification of received message.
                sendNotification(extras);
                Log.i(TAG, "Received: " + extras.toString());
                
            }
        }
        // Release the wake lock provided by the WakefulBroadcastReceiver.
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }

    // Put the message into a notification and post it.
    // This is just one simple example of what you might choose to do with
    // a GCM message.
    
    @SuppressLint("NewApi")
	public void SaveMessgaBundle(Bundle extras) {
    	
    	
    	 SharedPreferences mSharedPreferences = this.getApplicationContext().getSharedPreferences("MyPref", 0);
    	 Editor e = mSharedPreferences.edit();
    	 e.putString(ANCloudMessageService.PROPERTY_MESSAGE, extras.toString());
    	 e.commit(); // save changes
    	 
    	 
    	 Log.i(TAG, "Push Notification Saved");
    }
    @SuppressLint("NewApi")
	private void sendNotification(Bundle extras) {
    	 Log.i(TAG, "Push Notification Sended: ");
    	 
    	 try {
    		    SaveMessgaBundle(extras);
    		    
    		    SharedPreferences prefs = this.getApplicationContext().getSharedPreferences(ANCloudMessageService.PN_PREFS_KEY, 0);
    	        String iconName = prefs.getString(ANCloudMessageService.ICON_NAME, "");
    	        String soundName = prefs.getString(ANCloudMessageService.SOUND_NAME, "");
    	        boolean vibro = prefs.getBoolean(ANCloudMessageService.VIBRATION, false);
    	        boolean showIfAppForeground = prefs.getBoolean(ANCloudMessageService.SHOW_WHEN_APP_FOREGROUND, true);
    	        boolean useParse = prefs.getBoolean(ANCloudMessageService.USE_PARSE, false);
    	        
    	        Log.d("AndroidNative", "Push Notification Show when App Is Foreground " + showIfAppForeground);
    	        
    	        if (!showIfAppForeground) {
    	    		//Check Current Foreground Activity Name
    	    		ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
    	    	    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
    	    	    if (!tasks.isEmpty()) {
    	    	    	ComponentName topActivity = tasks.get(0).topActivity;
    	    	      	if (topActivity.getPackageName().equals(getApplicationContext().getPackageName())) {
    	    	      		Log.d("AndroidNative", "App is Foreground, so don't show received push notification");
    	    	      		return;
    	    	        }
    	    	    }
    	    	}
    	    	
    	    	String title = extras.getString("title");
    	    	String message = extras.getString("alert");
    	    	
    	    	if (useParse) {
    	    		if (extras.containsKey("data")) {
    	    			JSONObject json = new JSONObject(extras.getString("data"));    	    			
    	    			if (json.has("data")) {
    	    				JSONObject data = json.getJSONObject("data");
    	    				
                	    	title = data.getString("title");
                	    	message = data.getString("alert");
    	    			}
    	    		}
    	    	}
    	    	    	 
    	        mNotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
    	        Intent launcherIntent = getPackageManager().getLaunchIntentForPackage(getApplicationContext().getPackageName());    	  
    	        
    	        int requestID = (int) System.currentTimeMillis();
    	        Log.d(TAG, "Data retrived, requestID: " + requestID);
    	        
    	        PendingIntent contentIntent = PendingIntent.getActivity(this, requestID, launcherIntent, 0);
    	        
    	        int iconId = 0x7f020000;
    	        Resources res = this.getResources();
    	       	int id = res.getIdentifier(iconName, "drawable", this.getPackageName());
    	        iconId = id == 0 ? iconId : id;
    	        
    	        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this)
    		        .setSmallIcon(iconId)
    		        .setContentTitle(title)
    		        .setStyle(new NotificationCompat.BigTextStyle()
    		        .bigText(message))
    		        .setContentText(message);
    	        
    	        id = res.getIdentifier(soundName, "raw", this.getPackageName());
    	        if (id != 0) {
    	        	Uri uri = Uri.parse("android.resource://" + this.getPackageName() + "/" + id);
    	        	mBuilder.setDefaults(Notification.DEFAULT_LIGHTS);
    	            mBuilder.setSound(uri);
    	        } else {
    	        	mBuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS);
    	        }
    	        
    	        if (vibro) {
    	        	mBuilder.setVibrate(new long[] {500, 500, 500, 500});
    	        } else {
    	        	mBuilder.setVibrate(new long[]{});
    	        }

    	        mBuilder.setContentIntent(contentIntent).setAutoCancel(true);
    	        mNotificationManager.notify(requestID, mBuilder.build());
    	        
    	 } catch(Exception ex) {
    		 Log.d(TAG, ex.getMessage());
    		 ex.printStackTrace();
    	 }
        
    }
}
