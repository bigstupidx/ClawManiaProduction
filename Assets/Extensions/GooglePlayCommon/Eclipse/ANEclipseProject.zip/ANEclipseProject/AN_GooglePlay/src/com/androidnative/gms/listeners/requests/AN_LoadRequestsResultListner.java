package com.androidnative.gms.listeners.requests;

import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.request.Requests.LoadRequestsResult;


public class AN_LoadRequestsResultListner implements ResultCallback<LoadRequestsResult>{

	@Override
	public void onResult(LoadRequestsResult result) {
		
		
		
	}

}
