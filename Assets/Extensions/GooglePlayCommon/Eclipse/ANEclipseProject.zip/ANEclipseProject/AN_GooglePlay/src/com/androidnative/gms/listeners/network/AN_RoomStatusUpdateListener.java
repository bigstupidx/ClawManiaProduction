package com.androidnative.gms.listeners.network;

import java.util.List;

import android.util.Log;


import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.unity3d.player.UnityPlayer;

public class AN_RoomStatusUpdateListener implements RoomStatusUpdateListener{

	@Override
	public void onConnectedToRoom(Room arg0) {

		Log.d(GameClientManager.TAG, "onConnectedToRoom+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnConnectedToRoom", "");
		
	}

	@Override
	public void onDisconnectedFromRoom(Room arg0) {
		Log.d(GameClientManager.TAG, "onDisconnectedFromRoom+");

		
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnDisconnectedFromRoom", "");
		
	}

	@Override
	public void onP2PConnected(String arg0) {
		
		Log.d(GameClientManager.TAG, "onP2PConnected+");
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnP2PConnected", arg0);
		
	}

	@Override
	public void onP2PDisconnected(String arg0) {
		Log.d(GameClientManager.TAG, "onP2PDisconnected+");
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnP2PDisconnected", arg0);
		
	}

	@Override
	public void onPeerDeclined(Room arg0, List<String> arg1) {
	
		Log.d(GameClientManager.TAG, "onPeerDeclined+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeerDeclined", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onPeerInvitedToRoom(Room arg0, List<String> arg1) {
	
		Log.d(GameClientManager.TAG, "onPeerInvitedToRoom+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeerInvitedToRoom", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onPeerJoined(Room arg0, List<String> arg1) {
		Log.d(GameClientManager.TAG, "onPeerJoined+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeerJoined", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onPeerLeft(Room arg0, List<String> arg1) {
		
		Log.d(GameClientManager.TAG, "onPeerLeft+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeerLeft", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onPeersConnected(Room arg0, List<String> arg1) {
		
		Log.d(GameClientManager.TAG, "onPeersConnected+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeersConnected", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onPeersDisconnected(Room arg0, List<String> arg1) {
		Log.d(GameClientManager.TAG, "onPeersDisconnected+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnPeersDisconnected", PartisipantsIdsToString(arg1));
		
	}

	@Override
	public void onRoomAutoMatching(Room arg0) {
		Log.d(GameClientManager.TAG, "onRoomAutoMatching+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomAutoMatching", "");
		
	}

	@Override
	public void onRoomConnecting(Room arg0) {
		Log.d(GameClientManager.TAG, "onRoomConnecting+");
		RealTimeMultiplayerController.GetInstance().OnRoomUpdated(arg0);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomConnecting", "");
		
	}
	
	
	private String PartisipantsIdsToString( List<String> ids) {
		String ParticipantIds = "";
		
		boolean first = true;
		for(String id : ids) {
			if(first) {
				first = false;
				ParticipantIds += id;
			} else {
				ParticipantIds += "," + id;
			}
		}
		
		return ParticipantIds;
	}

}
