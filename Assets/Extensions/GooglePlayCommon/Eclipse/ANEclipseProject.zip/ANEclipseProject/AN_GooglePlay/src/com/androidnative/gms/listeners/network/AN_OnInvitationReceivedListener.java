package com.androidnative.gms.listeners.network;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.core.GameInvitationManager;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.unity3d.player.UnityPlayer;

public class AN_OnInvitationReceivedListener implements OnInvitationReceivedListener {

	@Override
	public void onInvitationReceived(Invitation invitation) {
		Log.d(GameClientManager.TAG, "onInvitationReceived+");
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_INIVITATION_LISTENER, "OnInvitationReceived", GameInvitationManager.GetInviteString(invitation));
		
	}

	@Override
	public void onInvitationRemoved(String invitationId) {
		Log.d(GameClientManager.TAG, "onInvitationRemoved- " + invitationId);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_INIVITATION_LISTENER, "OnInvitationRemoved", invitationId);
		
	}

}
