package com.androidnative.gms.listeners.tbm;

import java.util.Iterator;

import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.core.GameInvitationManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.InvitationBuffer;
import com.google.android.gms.games.multiplayer.Invitations;
import com.google.android.gms.games.multiplayer.Invitations.LoadInvitationsResult;

import com.unity3d.player.UnityPlayer;

public class AN_OnLoadInvitationsResult implements ResultCallback<Invitations.LoadInvitationsResult> {
	private final String TAG = "AndroidNative";

	@Override
	public void onResult(LoadInvitationsResult result) {
		int statusCode = result.getStatus().getStatusCode();		
		Log.d(TAG, "LoadInvitationsResult statusCode: " + statusCode);
		
		StringBuilder invitesData = new StringBuilder();
		invitesData.append(statusCode);
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			invitesData.append(GameClientManager.UNITY_SPLITTER);
			
			InvitationBuffer invitesBuffer = result.getInvitations();
			if (invitesBuffer != null) {
				Iterator<Invitation> invites = invitesBuffer.iterator();
				while(invites.hasNext()) {
					Invitation invite = invites.next();
					invitesData.append(GameInvitationManager.GetInviteString(invite));
					invitesData.append(GameClientManager.UNITY_SPLITTER);
				}
			}
			
			invitesData.append(GameClientManager.UNITY_EOF);
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_INIVITATION_LISTENER, "OnLoadInvitationsResult", invitesData.toString());
	}

}
