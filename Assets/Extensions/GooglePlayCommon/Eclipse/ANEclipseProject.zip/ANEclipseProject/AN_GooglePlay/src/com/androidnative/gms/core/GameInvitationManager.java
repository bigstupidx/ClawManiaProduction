package com.androidnative.gms.core;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.gms.listeners.network.AN_OnInvitationReceivedListener;
import com.androidnative.gms.listeners.tbm.AN_OnLoadInvitationsResult;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.unity3d.player.UnityPlayer;

public class GameInvitationManager {
	private static GameInvitationManager _instance = null;
	
	public static GameInvitationManager GetInstance() {
		if (_instance == null) {
			_instance = new GameInvitationManager();
		}

		return _instance;
	}
	
	public void onConnected(Bundle connectionHint)  {
		
		 Log.d(GameClientManager.TAG, "GameInvitationManager onConnected");	
		 
		 if(connectionHint != null) {
			 //Parse and send invitation, if we are in Real-Time Match			 
			 Invitation inv = connectionHint.getParcelable(Multiplayer.EXTRA_INVITATION);
			 if(inv != null) {
				 Log.d(GameClientManager.TAG, "We got Invitation for Real-Time Match, So, send invitation for futher decisions");				 

				 SendAcceptedInvite(inv);
				 return;
			 }
			 
			 //Parse and send Match object, if we are in Turn-Based Match
			 TurnBasedMatch match = connectionHint.getParcelable(Multiplayer.EXTRA_TURN_BASED_MATCH);
			 if (match != null) {
				 SendInitiatedMatch(match);
			 }
		 }
	}
	
	public void onActivityResult(int request, int response, Intent data) {
		switch (request) {
		case GameClientManager.TBM_INBOX_RESULT:
        case GameClientManager.RTM_INBOX_RESULT:
        	handleInvitationInboxResult(response, data);
        	break;
        default: break;
		}
	}
	
	// Handle the result of the invitation inbox UI, where the player can pick
	// an invitation
	// to accept. We react by accepting the selected invitation, if any.
	private void handleInvitationInboxResult(int response, Intent data) {
		Log.d(GameClientManager.TAG, "GameInvitationManager::handleInvitationInboxResult. Response code: " + response);

		if (data != null) {
			Invitation inv = data.getExtras().getParcelable(Multiplayer.EXTRA_INVITATION);
			if(inv != null) {
			   Log.d(GameClientManager.TAG, "GameInvitationManager has Multiplayer.EXTRA_INVITATION");
			   SendAcceptedInvite(inv);
			   return;
			}
			
			//Parse and send Match object, if we are in Turn-Based Match
			 TurnBasedMatch match = data.getExtras().getParcelable(Multiplayer.EXTRA_TURN_BASED_MATCH);
			 if (match != null) {
				 SendInitiatedMatch(match);
			 }
		}
		 
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_INIVITATION_LISTENER, "OnInvitationBoxUiClosed", Integer.toString(response));
	}
	
	private void SendInitiatedMatch(TurnBasedMatch match) {
		Log.d(GameClientManager.TAG, "We got invitation for Turn-Based Match. So, start match with accepted invitation");
		
		StringBuilder info = new StringBuilder();
		info.append(GamesStatusCodes.STATUS_OK);
		info.append(GameClientManager.UNITY_SPLITTER);					
		info.append(TurnBasedMultiplayerController.GetMatchString(match));
		 
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnMatchInitiatedCallback", info.toString());
	}
	
	private void SendAcceptedInvite(Invitation inv) {
		 UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_INIVITATION_LISTENER, "OnInvitationAccepted", GetInviteString(inv));
		 Log.d(GameClientManager.TAG, "inv sent");	
	}
	
	public static String GetInviteString(Invitation inv){
		StringBuilder builder = new StringBuilder();
		builder.append(inv.getInvitationId());
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(inv.getCreationTimestamp());
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(inv.getInvitationType());
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(inv.getVariant());
		builder.append(GameClientManager.UNITY_SPLITTER);
		builder.append(GameClientManager.SerializeParticipantInfo(inv.getInviter()));
		
		return builder.toString();
	}
	
	public static void registerInvitationListener() {
		Games.Invitations.registerInvitationListener(GameClientManager.API(), new AN_OnInvitationReceivedListener());
	}
	
	public static void unregisterInvitationListener() {
		Games.Invitations.unregisterInvitationListener(GameClientManager.API());
	}
	
	public static void loadAllInvitations() {
		Games.Invitations.loadInvitations(GameClientManager.API(), Multiplayer.SORT_ORDER_MOST_RECENT_FIRST).setResultCallback(new AN_OnLoadInvitationsResult());
	}
}
