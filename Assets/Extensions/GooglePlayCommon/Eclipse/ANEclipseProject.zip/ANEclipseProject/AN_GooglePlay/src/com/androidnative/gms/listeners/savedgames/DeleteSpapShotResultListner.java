package com.androidnative.gms.listeners.savedgames;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.snapshot.Snapshots.DeleteSnapshotResult;
import com.unity3d.player.UnityPlayer;

public class DeleteSpapShotResultListner implements ResultCallback<DeleteSnapshotResult>{

	@Override
	public void onResult(DeleteSnapshotResult result) {
		 int status = result.getStatus().getStatusCode();
		 StringBuilder  builder = new StringBuilder();
		 builder.append(status);
		 
		 if(status == GamesStatusCodes.STATUS_OK) {
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 builder.append(result.getSnapshotId());
		 }
		 
		 UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnDeleteResult", builder.toString()); 
		
	}

}
