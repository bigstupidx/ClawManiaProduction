package com.androidnative.gms.utils;

import java.io.IOException;

import android.os.AsyncTask;
import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.unity3d.player.UnityPlayer;

public class PS_Utility {
	
	
	public static String UTIL_LISTNER_NAME = "GooglePlayUtils";

	
	public static void GetAdvertisingId() {
		AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				
				String id = "";
				boolean isLAT = false;
				  
				
				Info adInfo = null;
				  try {
						adInfo = AdvertisingIdClient.getAdvertisingIdInfo(AnUtility.GetApplicationContex());
						id = adInfo.getId();
						isLAT = adInfo.isLimitAdTrackingEnabled();
				  } catch (IOException e) {
				    // Unrecoverable error connecting to Google Play services (e.g.,
				    // the old version of the service doesn't support getting AdvertisingId).
					  
				  } catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				 
				  } catch (GooglePlayServicesNotAvailableException e) {
				    // Google Play services is not available entirely.
				  } catch (GooglePlayServicesRepairableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  
				  
				  StringBuilder info = new StringBuilder();

				  
				  info.append(id);
				  info.append(GameClientManager.UNITY_SPLITTER);
				  if(isLAT) {
					  info.append("true");
				  } else {
					  info.append("false");
				  }
					
				  UnityPlayer.UnitySendMessage(UTIL_LISTNER_NAME, "OnAdvertisingIdLoaded", info.toString());
				  
				return null;
			}
			
			
		};
		
		task.execute();
	}
	
	
	public static void PrintGooglePlayConnectionFailedResult(ConnectionResult arg0) {

		String describtion  = "UNKNOWN";
		
		switch(arg0.getErrorCode()) {
		case 16:
			describtion = "API_UNAVAILABLE - One of the API components you attempted to connect to is not available. The API will not work on this device, and updating Google Play services will not likely solve the problem. Using the API on the device should be avoided.";
			break;
			
		case 13:
			describtion = "CANCELED - The client canceled the connection by calling disconnect(). Only returned by blockingConnect().";
			break;

		case 10:
			describtion = "DEVELOPER_ERROR - The application is misconfigured. This error is not recoverable and will be treated as fatal. The developer should look at the logs after this to determine more actionable information.";
			break;
		case 8:
			describtion = "INTERNAL_ERROR - An internal error occurred. Retrying should resolve the problem.";
			break;
		case 15:
			describtion = "INTERRUPTED - An interrupt occurred while waiting for the connection complete. Only returned by blockingConnect().";
			break;
		case 5:
			describtion = "INVALID_ACCOUNT - The client attempted to connect to the service with an invalid account name specified.";
			break;
		case 11:
			describtion = "LICENSE_CHECK_FAILED - The application is not licensed to the user. This error is not recoverable and will be treated as fatal.";
			break;
		case 7:
			describtion = "NETWORK_ERROR - A network error occurred. Retrying should resolve the problem.";
			break;
		case 6:
			describtion = "RESOLUTION_REQUIRED - Completing the connection requires some form of resolution. A resolution will be available to be started with startResolutionForResult(Activity, int). If the result returned is RESULT_OK, then further attempts to connect should either complete or continue on to the next issue that needs to be resolved.";
			break;
			
		case 3:
			describtion = "SERVICE_DISABLED - The installed version of Google Play services has been disabled on this device. The calling activity should pass this error code to getErrorDialog(int, Activity, int) to get a localized error dialog that will resolve the error when shown.";
			break;
			
		case 9:
			describtion = "SERVICE_INVALID - The version of the Google Play services installed on this device is not authentic.";
			break;
			
		case 1:
			describtion = "SERVICE_MISSING - Google Play services is missing on this device. The calling activity should pass this error code to getErrorDialog(int, Activity, int) to get a localized error dialog that will resolve the error when shown.";
			break;
			
		case 2:
			describtion = "SERVICE_VERSION_UPDATE_REQUIRED - The installed version of Google Play services is out of date. The calling activity should pass this error code to getErrorDialog(int, Activity, int) to get a localized error dialog that will resolve the error when shown.";
			break;
			
		case 4:
			describtion = "SIGN_IN_REQUIRED - The client attempted to connect to the service but the user is not signed in. The client may choose to continue without using the API or it may call startResolutionForResult(Activity, int) to prompt the user to sign in. After the sign in activity returns with RESULT_OK further attempts to connect should succeed.";
			break;
			
			
		case 14:
			describtion = "TIMEOUT - The timeout was exceeded while waiting for the connection to complete. Only returned by blockingConnect().";
			break;
			
		}
		
		
		Log.d("AndroidNative", "*************************************************************");
		Log.d("AndroidNative", "*************************************************************");
	    Log.d("AndroidNative", "*************** GOOGLE PLAY CONNECTION FAILED ***************");
	    Log.d("AndroidNative", "ERROR CODE: "     +  Integer.toString(arg0.getErrorCode()) + " ***************");
	    Log.d("AndroidNative", "HAS RESOLUTION: " + String.valueOf(arg0.hasResolution()) + " ***************");
	    Log.d("AndroidNative", "DESCRIBTION: "     +  describtion);
	    Log.d("AndroidNative", "READ MORE: http://developer.android.com/reference/com/google/android/gms/common/ConnectionResult.html");
	    Log.d("AndroidNative", "*************************************************************");
	    Log.d("AndroidNative", "*************************************************************");
	    
	}
}
