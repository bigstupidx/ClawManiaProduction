package com.androidnative.gms.listeners.tbm;


import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.network.TurnBasedMultiplayerController;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.UpdateMatchResult;
import com.unity3d.player.UnityPlayer;

public class AN_OnUpdateMatchResult implements ResultCallback<TurnBasedMultiplayer.UpdateMatchResult> {

	@Override
	public void onResult(UpdateMatchResult result) {
		
		int statusCode = result.getStatus().getStatusCode();
		
		Log.d("AndroidNative", "AN_OnUpdateMatchResult  statusCode:" + statusCode);
		
		
		StringBuilder info = new StringBuilder();
		info.append(statusCode);
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			info.append(GameClientManager.UNITY_SPLITTER);
			info.append(TurnBasedMultiplayerController.GetMatchString(result.getMatch()));
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_TBM_LISTENER, "OnUpdateMatchResult", info.toString());
		
	}

}
