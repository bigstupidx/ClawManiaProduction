package com.androidnative.gms.core;

import com.google.android.gms.common.ConnectionResult;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.os.Handler;
import android.util.Log;

public class GooglePlaySupportActivity extends Activity {

	private static final String BRIDGED_INTENT_KEY = "BRIDGED_INTENT";
	private static final String REQUEST_TYPE_CODE = "REQUEST_TYPE_CODE";
	private static final String BRIDGED_REQUEST_CODE_KEY = "BRIDGED_REQUEST_CODE_KEY";
	private static final String BRIDGED_ACCOUNT_KEY = "BRIDGED_ACCOUNT_KEY";

	
	public static final int BRIDJET_INTENT_REQUEST = 100;
	public static final int GOOGLE_PLAY_CONNECTION = 101;
	public static final int GOOGLE_PLAY_CONNECTION_RESOLUTION = 102;
	
	private int typeCode;
	private int requestCode;
	private boolean resultWasSet = false;
	
	public static GooglePlaySupportActivity currentInstance;
	
	@Override
    protected void onStart() {
        
		Log.d("AndroidNative", "GooglePlaySupportActivity::onStart");
		
		
		typeCode = getIntent().getIntExtra(REQUEST_TYPE_CODE, 100);
		switch(typeCode) {
			case BRIDJET_INTENT_REQUEST:
				requestCode = getIntent().getIntExtra(BRIDGED_REQUEST_CODE_KEY, 0);
				Intent bridgedIntent = (Intent) getIntent().getParcelableExtra(BRIDGED_INTENT_KEY);
				startActivityForResult(bridgedIntent, requestCode);
				break;
			case GOOGLE_PLAY_CONNECTION_RESOLUTION:
				requestCode = getIntent().getIntExtra(BRIDGED_REQUEST_CODE_KEY, 0);
				if(GameClientManager.GetInstance().mHelper == null) {
					Log.d("AndroidNative", "GooglePlaySupportActivity GOOGLE_PLAY_CONNECTION_RESOLUTION mHelper is null");
					return;
				}
				ConnectionResult con = GameClientManager.GetInstance().mHelper.connectionToResolve;
				try {
					con.startResolutionForResult(this, requestCode);
				} catch (SendIntentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
				
			case GOOGLE_PLAY_CONNECTION:
				resultWasSet = true;
				currentInstance = this;
				String acc = getIntent().getStringExtra(BRIDGED_ACCOUNT_KEY);
				GameClientManager.GetInstance().mHelper.StartSignRequest(acc, this);
				break;
				
			
		}


        super.onStart();
    }
	
	@Override
    protected void onStop() {
		 Log.d("AndroidNative", "GooglePlaySupportActivity::onStop");
		 if(!resultWasSet) {
			 GameClientManager.GetInstance().onActivityResult(requestCode, Activity.RESULT_CANCELED, null);
		 }
		 super.onStop();
	}
	
	 @Override
	 protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		 Log.d("AndroidNative", "GooglePlaySupportActivity::onActivityResult");
		 try {
				Handler handler = new Handler();
				final int arRequest = requestCode;
				final int arResult = resultCode;
				final Intent arData = data;
				
				
				//sending activity result to check if user was disconnected while using google UI.
				GameClientManager.GetInstance().onActivityResultDiconnectCheck(arRequest, arResult, arData);
				
				// delay between sending result, since unity will report un-pause only in next frame
				handler.postDelayed(new Runnable() {
				            public void run() {
				            	GameClientManager.GetInstance().onActivityResult(arRequest, arResult, arData);
				            }
				        }, 1000);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "GooglePlaySupportActivity::onActivityResult Error: " + ex.getMessage());
			}
		 	super.onActivityResult(requestCode, resultCode, data);

		 	
		 	finish(); 
	    }
	
	
	
	public static void startProxyForResult(Intent intent, int requestCode) {
		
		Intent i = CreateIntent();
		i.putExtra(REQUEST_TYPE_CODE, BRIDJET_INTENT_REQUEST);
		i.putExtra(BRIDGED_REQUEST_CODE_KEY, requestCode);
		i.putExtra(BRIDGED_INTENT_KEY, intent);

		StartProxy(i);
		
	}
	
	
	public static void startProxyForGPReolution(int requestCode) {
		Intent i = CreateIntent();
		i.putExtra(REQUEST_TYPE_CODE, GOOGLE_PLAY_CONNECTION_RESOLUTION);
		i.putExtra(BRIDGED_REQUEST_CODE_KEY, requestCode);
		
		StartProxy(i);
	}
	
	public static void startProxyForGPConnection(String account) {
		Intent i = CreateIntent();
		i.putExtra(REQUEST_TYPE_CODE, GOOGLE_PLAY_CONNECTION);
		i.putExtra(BRIDGED_ACCOUNT_KEY, account);
		
		StartProxy(i);
	}
	
	
	public static Intent CreateIntent() {
		return  new Intent(UnityPlayer.currentActivity, GooglePlaySupportActivity.class);
	}
	
	public static void StartProxy(Intent i) {
		UnityPlayer.currentActivity.startActivity(i);
	}
	
	public static void FinishActivity() {
		if(currentInstance != null) {
			currentInstance.finish();
			currentInstance = null;
		}
	}
}
