/** Automatically generated file. DO NOT MODIFY */
package com.androidnative.an_googleplay;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}