package com.androidnative.billing.core.listeners;

import com.androidnative.billing.interfaces.QueryInventoryFinishedListener;
import com.androidnative.billing.models.BillingResult;
import com.androidnative.billing.models.Inventory;

public class AN_QueryInventoryFinishedListener implements QueryInventoryFinishedListener {

	@Override
	public void onQueryInventoryFinished(BillingResult result, Inventory inv) {
		// TODO Auto-generated method stub
		
	}

}
